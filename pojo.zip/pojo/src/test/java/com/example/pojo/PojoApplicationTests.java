package com.example.pojo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PojoApplicationTests {

	@Test
	void contextLoads() {
	}

}
